# Continuous Mobile Authentication on HMOG

Reproducibility package for the manuscript **“Continuous Behavioral Authentication for Mobile Devices Using an Adaptive LSTM-Based Intelligent Agent”** by Vassiliy Serbin, Madi Gali, and Maksim Iavich.

The package implements a session-disjoint evaluation of smartphone behavioral authentication using accelerometer and gyroscope data from the HMOG dataset. It compares linear SVM, random forest, and LSTM classifiers and then performs a paired ablation of a frozen LSTM threshold against an online exponentially weighted moving-average (EMA) threshold.

The main empirical result is negative and security-relevant: under the evaluated balanced alternating zero-effort attack stream, the tested EMA rule does **not** improve the frozen threshold.

## Included artifacts

- `src/hmog_revised_experiment.py`: canonical experiment pipeline used for the reported results.
- `results/revised_results_by_fold.csv`: fold-level EER, FAR, FRR, and HTER values.
- `results/revised_results_summary.csv`: mean and standard deviation across five folds.
- `results/revised_fold_protocol.json`: session assignments and the selected LSTM epoch in every fold.
- `results/revised_experiment_metadata.json`: fixed preprocessing, evaluation, drift, and agent parameters.
- `results/hmog_sequences_100.quality.json`: six sessions skipped because an inertial file was empty.
- `results/revised_drift_hter.png`: aggregate static-versus-adaptive HTER plot.
- `metadata/dataset_exclusions.json`: complete accounting of the six empty-file sessions and two absent sessions.

Raw HMOG files and the derived sequence cache are intentionally excluded. The HMOG license does not permit this repository to redistribute the dataset.

## Reported results

Clean-session macro EER, mean ± standard deviation across five folds:

| Classifier | EER (%) |
|---|---:|
| Linear SVM | 29.92 ± 0.80 |
| Random forest | 24.05 ± 0.86 |
| LSTM | 21.87 ± 1.01 |

Validation-calibrated operating-point HTER:

| Final drift magnitude | Frozen threshold (%) | EMA threshold (%) |
|---:|---:|---:|
| 0 | 23.19 ± 0.95 | 24.53 ± 1.28 |
| 1 | 23.63 ± 1.10 | 25.02 ± 1.66 |
| 2 | 24.89 ± 1.37 | 26.39 ± 2.12 |

The static and adaptive conditions use the same sampled impostor attempts within each fold and drift condition. The random generator is reinitialized with a drift-dependent seed, so different drift levels use independently sampled impostor streams; cross-drift HTER changes therefore include this resampling variation.

## Data access

Obtain HMOG from the [official HMOG project](https://hmog-dataset.github.io/hmog/) and comply with its license and citation requirements. Place the 100 subject ZIP archives in one local directory. Do not commit the archives or a generated `.npz` cache to this repository.

The released run used 100 subjects and 4,784 sequences from 2,392 usable sessions. The data-quality accounting is recorded in `metadata/dataset_exclusions.json`.

## Environment

The released results were generated with:

- Python 3.13.9
- NumPy 2.3.5
- pandas 2.3.3
- SciPy 1.16.3
- scikit-learn 1.7.2
- PyTorch 2.12.0
- Matplotlib 3.10.6

Create an isolated environment and install the pinned dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

PyTorch installation details can depend on the operating system and accelerator. If the pinned wheel is unavailable for a platform, follow the official PyTorch installation instructions and record the substituted version.

## Reproduce the experiment

```bash
python src/hmog_revised_experiment.py \
  --data-dir /path/to/public_dataset \
  --output-dir reproduced_results \
  --max-subjects 100 \
  --rebuild-cache
```

The full five-fold run trains an LSTM, SVM, and 300-tree random forest in each fold and can take substantial time. The script uses Apple MPS when available, then CUDA, and otherwise the CPU. Small numerical differences may occur across hardware and library backends even with the fixed random seed.

The output directory will contain a derived HMOG sequence cache (`hmog_sequences_100.npz`). This cache is for local use only and must not be redistributed.

## Protocol boundaries

- The evaluation is session-disjoint but closed-set: every enrolled subject occurs in model-fitting, validation, and test partitions through different complete sessions.
- Thresholds and agent parameters are fixed from validation data before test scoring.
- The drift experiment adds a linearly increasing direction in standardized feature space; it is a controlled stress test, not a claim that all real behavioral drift follows this model.
- Only HMOG was evaluated. Generalization to other devices, populations, sensor placements, and datasets remains untested.
- Accepted impostor scores can update the EMA profile. The implementation deliberately preserves this poisoning risk instead of using test labels to block updates.

## License and citation

The source code in this repository is released under the MIT License. That license does not apply to HMOG or grant permission to redistribute HMOG-derived data.

Citation metadata for this software package is provided in `CITATION.cff`.

